<?php
declare(strict_types = 1);
namespace hexydec\jslite;

class increment extends operator {
	
}
