<?php

/*
@name     Htmldoc
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  1.8.1
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/lib-htmldoc
@licence  https://github.com/ocmod-space/lib-htmldoc/blob/main/LICENSE.txt
*/


$_['heading_title'] = '#ocmod.space: htmldoc';
$_['text_extension'] = 'Розширення';
$_['text_edit'] = 'Редагування параметрів <b>Htmldoc</b>';
$_['text_made'] = 'Зроблено з <i class="fa fa-heart-o" aria-hidden="true" style=" background: -webkit-linear-gradient(#0066cc, #ffcc00); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i> в Україні';
$_['text_about'] = 'Модуль інсталює теку <a target="_blank" href="https://github.com/hexydec/htmldoc">HTMLDoc</a> - PHP HTML Document парсер і мініфікатор.';
